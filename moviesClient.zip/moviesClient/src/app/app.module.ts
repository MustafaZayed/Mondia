import { MoviesService } from './shared/movies/movies.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';

import { MatButtonModule, MatCardModule, MatInputModule, MatListModule, MatToolbarModule, MatMenuModule, MatTabsModule, MatOption, MatSelect, MatSelectModule, MatOptionModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieEditComponent } from './movie-edit/movie-edit.component';

import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CategoriesService } from './shared/categories/categories.service';
import { CategoryListComponent } from './category-list/category-list.component';
import { CategoryEditComponent } from './category-edit/category-edit.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/app-home', pathMatch: 'full' },
  {
    path: 'app-home',
    component: HomeComponent
  },
  {
    path: 'movie-add',
    component: MovieEditComponent
  },
  {
    path: 'movie-edit/:id',
    component: MovieEditComponent
  },
  {
    path: 'category-add',
    component: CategoryEditComponent
  },
  {
    path: 'category-edit/:id',
    component: CategoryEditComponent
  }
];


@NgModule({
  declarations: [
    AppComponent,
    MovieListComponent,
    MovieEditComponent,
    HomeComponent,
    CategoryListComponent,
    CategoryEditComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatCardModule,
    MatMenuModule,
    MatInputModule,
    MatListModule,
    MatToolbarModule,
    FormsModule,
    MatTabsModule,
    MatOptionModule,
    MatSelectModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [
    MoviesService,
    CategoriesService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

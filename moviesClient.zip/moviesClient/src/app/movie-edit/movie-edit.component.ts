import { CategoriesService } from './../shared/categories/categories.service';
import { MoviesService } from './../shared/movies/movies.service';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-movie-edit',
  templateUrl: './movie-edit.component.html',
  styleUrls: ['./movie-edit.component.css']
})
export class MovieEditComponent implements OnInit, OnDestroy {
  movie: any = {};
  selectedCat: any;
  categories: any = [];
  sub: Subscription;
  imageSrc: any = "";
  displayedImg:any;
  @ViewChild('fileUploader') fileUploader;
  constructor(private route: ActivatedRoute,
    
    private router: Router,
    private movieService: MoviesService,
    private categoryService: CategoriesService,) {
      
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      const id = params['id'];
      if (id) {
        this.movieService.get(id).subscribe((movie: any) => {
          console.log(movie)
          if (movie) {
            this.movie = movie;
            this.displayedImg = this.movie.image ? `data:image/png;base64,${this.movie.image}` : '';
            this.selectedCat = this.movie.category ? this.movie.category.id : "";
          } else {
            console.log(`movie with id '${id}' not found, returning to list`);
            this.gotoList();
          }
        });
      }
    });

    this.categoryService.categories.then((data: any) => {
      this.categories = data;
    });
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  gotoList() {
    this.router.navigate(['/app-home']);
  }

  save(form: any) {
    console.log(form)
    form.category = this.categories.find((cat) => cat.id == this.selectedCat) || null
    form.image = this.imageSrc.split(",")[1] || "";
    this.movieService.save(form).subscribe(result => {
      this.gotoList();
    }, error => console.error(error));
  }

  remove(id) {
    this.movieService.remove(id).subscribe(result => {
      this.gotoList();
    }, error => console.error(error));
  }

  getImage(e) {
    e.preventDefault();
    this.fileUploader.nativeElement.click();
  }

  handleInputChange(e) {
    var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];
    var pattern = /image-*/;
    var reader = new FileReader();
    if (!file.type.match(pattern)) {
      alert('invalid format');
      return;
    }
    reader.onload = this._handleReaderLoaded.bind(this);
    reader.readAsDataURL(file);
  }
  _handleReaderLoaded(e) {
    let reader = e.target;
    this.imageSrc = reader.result;
    this.displayedImg = this.imageSrc;
  }
}


import { DomSanitizer } from '@angular/platform-browser';
import { CategoriesService } from './../shared/categories/categories.service';
import { MoviesService } from './../shared/movies/movies.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {
  movies: any = [];
  originalMovies: any = [];
  categories: Array<any>;
  selectedCategory: any = "default";

  constructor(private movieService: MoviesService, private categoryService: CategoriesService,private domSan:DomSanitizer) { 
    
  }

  ngOnInit() {
    this.movieService.getAll().subscribe(data => {
      console.log(data)
      this.movies = data;
      this.originalMovies = data;
    });
    this.categoryService.categories.then((data: any) => {
      this.categories = data;
    });
  }

  onCategoryChange() {
    if (this.selectedCategory == "default") {
      this.movies = this.originalMovies;
    } else {
      this.movies = this.originalMovies.filter(movie => movie.category.id == this.selectedCategory)
    }
  }

}


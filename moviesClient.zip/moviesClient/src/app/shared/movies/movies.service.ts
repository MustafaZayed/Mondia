import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MoviesService {
  public serviceUrl = '//localhost:8080/moviesApi/movies';

  constructor(private http: HttpClient) {
  }

  getAll(): Observable<any> {
    return this.http.get(`${this.serviceUrl}`);
  }

  get(id: string) {
    return this.http.get(`${this.serviceUrl}/${id}`);
  }

  save(movie: any): Observable<any> {
    let result: Observable<Object>;
    if (movie['id']) {
      result = this.http.put(`${this.serviceUrl}/${movie.id}`, movie);
    } else {
      result = this.http.post(this.serviceUrl, movie);
    }
    return result;
  }

  remove(id) {
    return this.http.delete(`${this.serviceUrl}/${id}`);
  }
}
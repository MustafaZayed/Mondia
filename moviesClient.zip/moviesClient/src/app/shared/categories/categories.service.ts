import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class CategoriesService {
  upToDate:boolean = false;
  _categories:Array<any>;
  public serviceUrl = '//localhost:8080/categoriesApi/categories';

  constructor(private http: HttpClient) {
  }

  get categories(){
    return new Promise((resolve,reject)=>{
      if(this.upToDate){
        resolve(this._categories)
      }else{
        this.getAll().subscribe(data=>{
          this._categories = data;
          this.upToDate = true;
          resolve(this._categories)
        })
      }
    })
  }

  getAll(): Observable<any> {
    return this.http.get(`${this.serviceUrl}`);
  }

  get(id: string) {
    return this.http.get(`${this.serviceUrl}/${id}`);
  }

  save(cat: any): Observable<any> {
    let result: Observable<Object>;
    if (cat['id']) {
      result = this.http.put(`${this.serviceUrl}/${cat.id}`, cat);
    } else {
      result = this.http.post(this.serviceUrl, cat);
    }
    this.upToDate = false;
    return result;
  }

  remove(id) {
    this.upToDate = false;
    return this.http.delete(`${this.serviceUrl}/${id}`);
  }

}

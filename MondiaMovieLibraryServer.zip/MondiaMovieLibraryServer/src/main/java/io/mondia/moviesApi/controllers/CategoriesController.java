package io.mondia.moviesApi.controllers;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import io.mondia.moviesApi.model.Category;
import io.mondia.moviesApi.model.Movie;
import io.mondia.moviesApi.repository.CategoryRepository;
import io.mondia.moviesApi.repository.MovieRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "/categoriesApi")
public class CategoriesController {

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private MovieRepository movieRepository;

	@GetMapping("/categories")
	public List<Category> getAllCategories() {
		return categoryRepository.findAll();
	}

	@GetMapping("/categories/{id}")
	public Category getCategoryById(@PathVariable int id) {
		return categoryRepository.findOne(id);
	}

	@DeleteMapping("/categories/{id}")
	public void deleteCategory(@PathVariable int id) {
		// List<Movie> movies = movieRepository.findAll();
		// boolean hasMovies = false;
		// for (Movie m : movies) {
		// 	if (m.getCategory().getId() == id) {
		// 		hasMovies = true;
		// 	}
		// }
		// if (hasMovies) {
		// 	return ResponseEntity.ok("cannot delete category that has movies");
		// }else{
		// 	categoryRepository.delete(id);
		// 	return ResponseEntity.ok("deleted");
		// }
		categoryRepository.delete(id);
	}

	@PostMapping("/categories")
	public ResponseEntity<Object> createCategory(@RequestBody Category category) {
		System.out.println(category);
		Category savedCategory = categoryRepository.save(category);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedCategory.getId()).toUri();

		return ResponseEntity.created(location).build();
	}

	@PutMapping("/categories/{id}")
	public ResponseEntity<Object> updateCategory(@RequestBody Category category, @PathVariable int id) {
		category.setId(id);
		categoryRepository.save(category);
		return ResponseEntity.noContent().build();
	}

}
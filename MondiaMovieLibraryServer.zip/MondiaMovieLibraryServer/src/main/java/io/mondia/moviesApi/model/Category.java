package io.mondia.moviesApi.model;

import javax.persistence.*;

import org.hibernate.validator.constraints.*;

import java.util.Set;

@Entity
@Table(name = "category")
public class Category {
    private int id;
    @NotBlank
    private String name;
    private Set<Movie> movies;

    public Category(){

    }

    public Category(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
    // public Set<Movie> getMovies() {
    //     return movies;
    // }

    // public void setMovies(Set<Movie> movies) {
    //     this.movies = movies;
    // }

    @Override
    public String toString() {
        String result = String.format(
                "Category[id=%d, name='%s']%n",
                id, name);
        if (movies != null) {
            for(Movie movie : movies) {
                result += String.format(
                        "Movie[id=%d, title='%s']%n",
                        movie.getId(), movie.getTitle());
            }
        }

        return result;
    }
}

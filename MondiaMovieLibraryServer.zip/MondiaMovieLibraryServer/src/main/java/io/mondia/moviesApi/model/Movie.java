package io.mondia.moviesApi.model;

import javax.persistence.*;

import org.hibernate.validator.constraints.*;

@Entity
public class Movie{
    private int id;
    @NotBlank
    private String title;
    @NotBlank
    private String description;
    private Category category;

    @Lob @Basic(fetch = FetchType.LAZY)
    @Column(length=16777215,columnDefinition="MEDIUMBLOB")
    private byte[] image;

    public Movie() {

    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public byte[] getImage() {
        return image;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @ManyToOne
    @JoinColumn(name = "category_id")
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
